package com.hqm.thyme.controllers;

import com.hqm.thyme.forms.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Arrays;
import java.util.List;

@Controller
public class RegisterController {

    @RequestMapping(value = "/register")
    public String form(Model model){
        User user = new User();
        model.addAttribute("user", user);

        // Fixed typo: "Project Manager" instead of "Project Managemer"
        List<String> prof = Arrays.asList("Developer", "Tester", "Project Manager");
        model.addAttribute("prof", prof);

        return "register";  // Return the registration form view
    }

    @PostMapping(value = "/register")
    public String saveForm(@ModelAttribute("user") User user){
        System.out.println(user);  // Print user object to the console for debugging
        return "register_success";  // Redirect to success page after form submission
    }
}
