package com.hqm.thyme.forms;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType; // Tambahkan import ini
import javax.persistence.Table;
import java.time.LocalDate;

@Entity
@Table(name = "user")  // Menambahkan nama tabel (opsional)
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // Menentukan strategi ID
    private Long id;

    private String name;
    private String email;
    private String phone;
    private LocalDate birthday;
    private String jobType;
    private String gender;
    private String lastEducation;
    private String profession;
    private boolean married;
    private boolean nationalityVerified;
    private String note;

    // Getters dan setters untuk setiap field
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public String getProfession() {
        return profession;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public LocalDate getBirthday() {
        return birthday;
    }

    public void setBirthday(LocalDate birthday) {
        this.birthday = birthday;
    }

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getLastEducation() {
        return lastEducation;
    }

    public void setLastEducation(String lastEducation) {
        this.lastEducation = lastEducation;
    }

    public boolean isMarried() {
        return married;
    }

    public void setMarried(boolean married) {
        this.married = married;
    }

    public boolean isNationalityVerified() {
        return nationalityVerified;
    }

    public void setNationalityVerified(boolean nationalityVerified) {
        this.nationalityVerified = nationalityVerified;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}