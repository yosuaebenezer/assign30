package com.hqm.thyme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication  // Marks this class as the main entry point for Spring Boot application
public class ThymeApplication {

	public static void main(String[] args) {
		// This method runs the Spring Boot application
		SpringApplication.run(ThymeApplication.class, args);
	}
}
