package com.hqm.thyme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymeApplicationTests {

	@Test
	void contextLoads() {
	}

}
